.. soaplib documentation master file, created by
   sphinx-quickstart on Sat May  8 09:26:12 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to soaplib's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   pages/helloworld
   pages/usermanager
   pages/serializers
   pages/binaryfiles
   pages/message_api
   pages/hooks
   pages/apache_axis
   pages/indices_and_tables


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

